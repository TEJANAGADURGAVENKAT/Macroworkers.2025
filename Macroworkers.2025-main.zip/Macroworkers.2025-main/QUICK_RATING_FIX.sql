-- QUICK RATING FIX - Run this in Supabase SQL Editor
-- This will immediately fix the rating issue

-- Step 1: Fix the trigger to include ALL rated submissions (not just approved)
CREATE OR REPLACE FUNCTION update_worker_rating_and_designation()
RETURNS TRIGGER AS $$
DECLARE
  avg_rating DECIMAL(3,2);
  new_designation TEXT;
  total_ratings INTEGER;
BEGIN
  -- Only proceed if employer_rating_given was updated and is not null
  IF NEW.employer_rating_given IS NOT NULL AND 
     (OLD.employer_rating_given IS NULL OR OLD.employer_rating_given != NEW.employer_rating_given) THEN
    
    -- Calculate average rating for this worker from ALL submissions with ratings
    -- This includes approved, rejected, and any other status with ratings
    SELECT 
      COALESCE(AVG(employer_rating_given), 0.00),
      COUNT(*)
    INTO avg_rating, total_ratings
    FROM public.task_submissions 
    WHERE worker_id = NEW.worker_id 
      AND employer_rating_given IS NOT NULL;
    
    -- Determine designation based on average rating
    IF total_ratings = 0 THEN
      avg_rating := 0.00;
      new_designation := 'L1';
    ELSIF avg_rating < 3.0 THEN
      new_designation := 'L1';
    ELSIF avg_rating >= 3.0 AND avg_rating < 4.0 THEN
      new_designation := 'L2';
    ELSE
      new_designation := 'L3';
    END IF;
    
    -- Update worker profile with new rating and designation
    UPDATE public.profiles 
    SET 
      rating = avg_rating,
      designation = new_designation,
      last_rating_update = now(),
      updated_at = now()
    WHERE user_id = NEW.worker_id AND role = 'worker';
    
    -- Log the update for debugging
    RAISE NOTICE 'Updated worker % rating to % and designation to % (based on % ratings)', 
      NEW.worker_id, avg_rating, new_designation, total_ratings;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Step 2: Recreate the trigger
DROP TRIGGER IF EXISTS update_worker_rating_trigger ON public.task_submissions;
CREATE TRIGGER update_worker_rating_trigger
  AFTER UPDATE ON public.task_submissions
  FOR EACH ROW
  EXECUTE FUNCTION update_worker_rating_and_designation();

-- Step 3: Manually fix vivek's rating right now
UPDATE public.profiles 
SET 
  rating = (
    SELECT AVG(employer_rating_given) 
    FROM public.task_submissions 
    WHERE worker_id = profiles.user_id 
      AND employer_rating_given IS NOT NULL
  ),
  designation = CASE 
    WHEN (
      SELECT AVG(employer_rating_given) 
      FROM public.task_submissions 
      WHERE worker_id = profiles.user_id 
        AND employer_rating_given IS NOT NULL
    ) < 3.0 THEN 'L1'
    WHEN (
      SELECT AVG(employer_rating_given) 
      FROM public.task_submissions 
      WHERE worker_id = profiles.user_id 
        AND employer_rating_given IS NOT NULL
    ) >= 3.0 AND (
      SELECT AVG(employer_rating_given) 
      FROM public.task_submissions 
      WHERE worker_id = profiles.user_id 
        AND employer_rating_given IS NOT NULL
    ) < 4.0 THEN 'L2'
    ELSE 'L3'
  END,
  last_rating_update = now(),
  updated_at = now()
WHERE full_name ILIKE '%vivek%' AND role = 'worker';

-- Step 4: Verify the fix
SELECT 
  full_name,
  rating,
  designation,
  last_rating_update
FROM public.profiles 
WHERE full_name ILIKE '%vivek%' AND role = 'worker';

-- Step 5: Show all ratings for vivek
SELECT 
  ts.employer_rating_given,
  ts.rating_feedback,
  ts.status,
  t.title
FROM public.task_submissions ts
JOIN public.tasks t ON ts.task_id = t.id
WHERE ts.worker_id = (
  SELECT user_id 
  FROM public.profiles 
  WHERE full_name ILIKE '%vivek%' AND role = 'worker'
  LIMIT 1
)
AND ts.employer_rating_given IS NOT NULL
ORDER BY ts.submitted_at DESC;
